package com.shop_account_maintance.model;

import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

import java.util.Date;
import java.util.List;

public class ReceiptData {
    private String companyName;
    private String companyAddress;
    private String companyMobileNumber;
    private String soldBy;
    private String customerAddress;
    private String customerName;
    private String customerMNumber;
    private String paymentType;
    private Date date;
    private double totalAmount;
    private double taxAmount;
    private double discountAmount;
    private String billNumber;

    private List<SelectedProduct> selectedProductList;
    private JRBeanCollectionDataSource productListDataSource;

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public String getCompanyAddress() {
        return companyAddress;
    }

    public void setCompanyAddress(String companyAddress) {
        this.companyAddress = companyAddress;
    }

    public String getCompanyMobileNumber() {
        return companyMobileNumber;
    }

    public void setCompanyMobileNumber(String companyMobileNumber) {
        this.companyMobileNumber = companyMobileNumber;
    }

    public String getSoldBy() {
        return soldBy;
    }

    public void setSoldBy(String soldBy) {
        this.soldBy = soldBy;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerMNumber() {
        return customerMNumber;
    }

    public void setCustomerMNumber(String customerMNumber) {
        this.customerMNumber = customerMNumber;
    }

    public String getPaymentType() {
        return paymentType;
    }

    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }

    public double getDiscountAmount() {
        return discountAmount;
    }

    public void setDiscountAmount(double discountAmount) {
        this.discountAmount = discountAmount;
    }

    public String getBillNumber() {
        return billNumber;
    }

    public void setBillNumber(String billNumber) {
        this.billNumber = billNumber;
    }

    public List<SelectedProduct> getSelectedProductList() {
        return selectedProductList;
    }

    public void setSelectedProductList(List<SelectedProduct> selectedProductList) {
        this.selectedProductList = selectedProductList;
    }

    public JRBeanCollectionDataSource getProductListDataSource() {
        return new JRBeanCollectionDataSource(selectedProductList);
    }

    public void setProductListDataSource(JRBeanCollectionDataSource productListDataSource) {
        this.productListDataSource = productListDataSource;
    }

    @Override
    public String toString() {
        return "ReceiptData{" +
                "companyName='" + companyName + '\'' +
                ", companyAddress='" + companyAddress + '\'' +
                ", companyMobileNumber='" + companyMobileNumber + '\'' +
                ", soldBy='" + soldBy + '\'' +
                ", customerAddress='" + customerAddress + '\'' +
                ", customerName='" + customerName + '\'' +
                ", customerMNumber='" + customerMNumber + '\'' +
                ", paymentType='" + paymentType + '\'' +
                ", date=" + date +
                ", totalAmount=" + totalAmount +
                ", taxAmount=" + taxAmount +
                ", discountAmount=" + discountAmount +
                ", billNumber='" + billNumber + '\'' +
                ", selectedProductList=" + selectedProductList +
                '}';
    }
}
