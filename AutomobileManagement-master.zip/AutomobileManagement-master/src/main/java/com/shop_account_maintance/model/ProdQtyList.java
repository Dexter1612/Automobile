package com.shop_account_maintance.model;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProdQtyList {


	private static ProdQtyList obj=null;
	private static Map<String,Integer> prodIdQty = null;
	private static List<String> productlist=null;
	
	private ProdQtyList()
	{
		
	}//DEFAULT constructor
	

	public static ProdQtyList getInstanceOf_ProdQtyList()
	{
		if(obj==null)
		{
			obj=new ProdQtyList();
			return obj;
		}
		else
		{
			return obj;
			
		}
		
	}
	
	public static List<String> getInstanceOf_productlist()
	{
		if(productlist==null)
		{
			productlist=new ArrayList<String>();
			return productlist;
		}
		else
		{
			return productlist;
			
		}
		
	}
	
	public static Map<String,Integer> getInstanceOf_prodIdQty()
	{
		if(prodIdQty==null)
		{
			prodIdQty=new HashMap<String,Integer>();
			return prodIdQty;
		}
		else
		{
			return prodIdQty;
			
		}
		
	}

	public List<String> getProductlist() {
		return productlist;
	}

	public void setProductlist(List<String> productlist) {
		ProdQtyList.productlist = productlist;
	fireInsertQuery();
	}
	
	public void setprodIdQty(Map<String,Integer> prodIdQty) {
		ProdQtyList.prodIdQty = prodIdQty;
	}
	
	public  Map<String,Integer> getFinalList()
	{	List<String> list=obj.getProductlist();
	 Map<String, Integer> hm = new HashMap<String, Integer>();
	
		 		 for (String i : list) { 
	            Integer j = hm.get(i); 
	            hm.put(i, (j == null) ? 1 : j + 1); 
	        } 
	  
		
		 for (Map.Entry<String, Integer> val : hm.entrySet()) { 
	            System.out.println("Element " + val.getKey() + " "
	                               + "occurs"
	                               + ": " + val.getValue() + " times"); 
	        }
		 
		
		
		return hm;
	}
	
	

/*	 public static void getInsertQuery()
	 {
		 Map<String, Integer> prodList = ProdQtyList.getFinalList();
		        // Create a new StringBuilder.
		        StringBuilder builder1 = new StringBuilder();
				
		        for (Map.Entry<String, Integer> val : prodList.entrySet()) {
		        	builder1.append("'" +val.getKey()+"',"+"'"+ val.getValue() + "',"+"'"+ 100);
		        }
		        // Convert to string.
		        String result = builder1.toString();

		        // Print result.
		        System.out.println(result);
	}*/
	
	 public static void fireInsertQuery()
	 {
	/*	 Map<String, Integer> prodList = ProdQtyList.getFinalList();
	*/	        // Create a new StringBuilder.
		 Map<String, Integer> prodList = obj.getFinalList();
	        StringBuilder builder1 = new StringBuilder();
			
	        for (Map.Entry<String, Integer> val : prodList.entrySet()) {
	        	builder1.append("('" +val.getKey()+"',"+"'"+ val.getValue() + "',"+"'"+ 80+"'),");
	        }
	
		 
			    String r=builder1.deleteCharAt(builder1.length() - 1).toString();
		        String qq="insert into prodQty values"+r;
		        

		        // Print result.
		        System.out.println(r);
		        System.out.println(qq);
//		        
//		        try {
//					Connection con1 = DbConnection.getconnection();
//					Statement cs = con1.createStatement();
//							
//					String dropQuery ="DELETE FROM prodQty";
//					cs.addBatch(dropQuery); 
//					cs.addBatch(qq);
//					int[] count=cs.executeBatch();
//					System.out.println(count);
//					}catch (Exception e) {
//					
//					System.out.println(e);
//					}
		       
		        
	 }	
/*
public static void main(String [] args)
{
	getInsertQuery();
	}
*/	
/*
		Iterator<String> itr=this.productlist.iterator();
		System.out.println("List Elements");
		   while(itr.hasNext())
			{
			   
			System.out.println(itr.next()+" ");
			}

	}
	*/
}

