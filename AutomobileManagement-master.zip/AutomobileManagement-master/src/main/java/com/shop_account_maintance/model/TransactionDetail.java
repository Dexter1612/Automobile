package com.shop_account_maintance.model;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity(name = "TRANSACTION_DETAIL")
public class TransactionDetail {

    @Id
    @GeneratedValue
    private Long id;
    private Long master_transaction_id;
    private String product_name;
    private int quantity;
    @CreationTimestamp
    private Timestamp insert_time;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMaster_transaction_id() {
        return master_transaction_id;
    }

    public void setMaster_transaction_id(Long master_transaction_id) {
        this.master_transaction_id = master_transaction_id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Timestamp getInsert_time() {
        return insert_time;
    }

    public void setInsert_time(Timestamp insert_time) {
        this.insert_time = insert_time;
    }

    @Override
    public String toString() {
        return "TransactionDetail{" +
                "id=" + id +
                ", master_transaction_id=" + master_transaction_id +
                ", product_name='" + product_name + '\'' +
                ", quantity=" + quantity +
                ", insert_time=" + insert_time +
                '}';
    }
}
