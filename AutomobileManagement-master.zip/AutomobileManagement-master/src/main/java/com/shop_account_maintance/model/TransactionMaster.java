package com.shop_account_maintance.model;

import org.hibernate.annotations.CreationTimestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.sql.Timestamp;

@Entity(name = "TRANSACTION_MASTER")
public class TransactionMaster {

    @Id
    @GeneratedValue
    private Long transaction_id;
    private String bill_number;
    private String mobile_number;
    private String customer_name;
    private String sold_by;
    @CreationTimestamp
    private Timestamp insert_time;
    private String payment_type;
    private double amount;
    private double discounted_amount;
    private double tax_amount;
    private String status;

    public Long getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(Long transaction_id) {
        this.transaction_id = transaction_id;
    }

    public String getBill_number() {
        return bill_number;
    }

    public void setBill_number(String bill_number) {
        this.bill_number = bill_number;
    }

    public String getMobile_number() {
        return mobile_number;
    }

    public void setMobile_number(String mobile_number) {
        this.mobile_number = mobile_number;
    }

    public String getCustomer_name() {
        return customer_name;
    }

    public void setCustomer_name(String customer_name) {
        this.customer_name = customer_name;
    }

    public String getSold_by() {
        return sold_by;
    }

    public void setSold_by(String sold_by) {
        this.sold_by = sold_by;
    }

    public Timestamp getInsert_time() {
        return insert_time;
    }

    public void setInsert_time(Timestamp insert_time) {
        this.insert_time = insert_time;
    }

    public String getPayment_type() {
        return payment_type;
    }

    public void setPayment_type(String payment_type) {
        this.payment_type = payment_type;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getDiscounted_amount() {
        return discounted_amount;
    }

    public void setDiscounted_amount(double discounted_amount) {
        this.discounted_amount = discounted_amount;
    }

    public double getTax_amount() {
        return tax_amount;
    }

    public void setTax_amount(double tax_amount) {
        this.tax_amount = tax_amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "TransactionMaster{" +
                "transaction_id=" + transaction_id +
                ", bill_number='" + bill_number + '\'' +
                ", mobile_number='" + mobile_number + '\'' +
                ", customer_name='" + customer_name + '\'' +
                ", sold_by='" + sold_by + '\'' +
                ", insert_time=" + insert_time +
                ", payment_type='" + payment_type + '\'' +
                ", amount=" + amount +
                ", discounted_amount=" + discounted_amount +
                ", tax_amount=" + tax_amount +
                ", status='" + status + '\'' +
                '}';
    }
}
