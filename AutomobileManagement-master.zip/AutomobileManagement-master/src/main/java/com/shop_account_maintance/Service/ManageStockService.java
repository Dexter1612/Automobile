package com.shop_account_maintance.Service;

import com.shop_account_maintance.Dao.ManageStockRepository;
import com.shop_account_maintance.model.ProductMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ManageStockService {

    @Autowired
    private ManageStockRepository manageStockRepository;

    public Iterable<ProductMaster> fetchAllProducts() {
       return manageStockRepository.findAll();
    }

    public void deleteProductFromDB(Long id) {
        manageStockRepository.delete(id);
    }

    public void updateProductInDB(Long id, int quantity, String productName) {
        int count = manageStockRepository.updateProductInDB(id, quantity, productName);
    }
}
