package com.shop_account_maintance.Service;

import com.shop_account_maintance.Controller.UserController;
import com.shop_account_maintance.Dao.BillGenerateDao;
import com.shop_account_maintance.Dao.SellProductRepository;
import com.shop_account_maintance.Dao.TransactionDetailsDao;
import com.shop_account_maintance.model.*;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ResourceLoader;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;

@Service
public class BillGenerateService {
    private static final Logger LOGGER= LoggerFactory.getLogger(BillGenerateService.class);

    @Autowired
    @Qualifier("jdbcTemplate")
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private ResourceLoader resourceLoader;

    @Autowired
    private BillGenerateDao billGenerateDao;

    @Autowired
    private TransactionDetailsDao transactionDetailsDao;

    @Autowired
    private SellProductRepository productRepository;

    @Autowired
    HttpSession httpSession;

    public JasperPrint exportPdfFile() throws SQLException, JRException, IOException {

        Connection conn = jdbcTemplate.getDataSource().getConnection();

        String path = resourceLoader.getResource("classpath:/jasper/invoice_template.jrxml").getURI().getPath();

        JasperReport jasperReport = JasperCompileManager.compileReport(path);
        JRDataSource dataSource = new JREmptyDataSource();

        // Parameters for report
        Map<String, Object> parameters = new HashMap<String, Object>();
        ReceiptData receiptData = new ReceiptData();
        receiptData.setCompanyName("Shiv Enterprises");
        receiptData.setCompanyAddress("Kalewadi Highway,Pimpri, Pune");
        receiptData.setCompanyMobileNumber("9730230263");
        receiptData.setSoldBy("Pratiksha Pundkare");
        receiptData.setCustomerAddress("Kalewadi");
        receiptData.setCustomerMNumber("7507956770");
        receiptData.setDate(Date.valueOf("2019-11-22"));

        receiptData.setPaymentType("Cash");
        receiptData.setTaxAmount(12);
        receiptData.setTotalAmount(1235);
        receiptData.setDiscountAmount(50);
        SelectedProduct selectedProduct = new SelectedProduct();
        selectedProduct.setAmount(100);
        selectedProduct.setName("defdd");
        selectedProduct.setQuantity(2);
        selectedProduct.setPrice(50);

        SelectedProduct selectedProduct1 = new SelectedProduct();
        selectedProduct1.setAmount(1000);
        selectedProduct1.setName("desfrg");
        selectedProduct1.setQuantity(10);
        selectedProduct1.setPrice(50000);

        List<SelectedProduct> listofProducts = new ArrayList<SelectedProduct>();
        listofProducts.add(selectedProduct);
        listofProducts.add(selectedProduct1);
        parameters.put("receiptData",receiptData);
        JRBeanCollectionDataSource productListDataSource = new JRBeanCollectionDataSource(listofProducts, false);
//        receiptData.setProductListDataSource(productListDataSource);
        parameters.put("productListDataSource",productListDataSource);
        JasperPrint print = JasperFillManager.fillReport(jasperReport, parameters,dataSource);
        LOGGER.info("Bill generate successfully@@@@@@@"+print);

        return print;
    }

    public long insertTransactionIntoDB() throws Exception {

        List<SelectedProduct> selectedProductList = new ArrayList<SelectedProduct>();
        SelectedProduct selectedProduct = new SelectedProduct();
        selectedProduct.setPrice(1000);
        selectedProduct.setQuantity(10);
        selectedProduct.setName("MRF Tyre");
        selectedProduct.setAmount(10000);
        selectedProduct.setId(Long.valueOf(2));

        SelectedProduct selectedProduct1 = new SelectedProduct();
        selectedProduct1.setPrice(99);
        selectedProduct1.setQuantity(100);
        selectedProduct1.setName("CEAT Tyre");
        selectedProduct1.setId(Long.valueOf(3));
        selectedProduct1.setAmount(9900);
        selectedProductList.add(selectedProduct1);
        selectedProductList.add(selectedProduct);

            TransactionMaster transactionMaster = new TransactionMaster();
            transactionMaster.setAmount(500);
            transactionMaster.setBill_number("A-999");
            transactionMaster.setCustomer_name("AAA");
            transactionMaster.setDiscounted_amount(12);
            transactionMaster.setMobile_number("9730230263");
            transactionMaster.setPayment_type("Card");
            transactionMaster.setSold_by((String) httpSession.getAttribute("username"));
            TransactionMaster transMaster = billGenerateDao.save(transactionMaster);
            System.out.println("Transaction ID:: "+transMaster.getTransaction_id());
            if (transMaster.getTransaction_id() > 0){
                createTransactionDetailList(selectedProductList, transMaster.getTransaction_id());
                updateProductMaster(selectedProductList);
             }else{
                throw new Exception("Failed to insert transaction..");
            }
            return transMaster.getTransaction_id();
    }

    private void updateProductMaster(List<SelectedProduct> selectedProductList) {
        LOGGER.info("Inside updateProductMaster with selected product::"+selectedProductList.size());
        for (SelectedProduct selectedProduct : selectedProductList) {
            ProductMaster productMaster = productRepository.findOne(selectedProduct.getId());
            if(productMaster !=null && productMaster.getProduct_id() == selectedProduct.getId()){
                int updatedQuantity = (productMaster.getQuantity() - selectedProduct.getQuantity()) < 0 ? 0
                        :productMaster.getQuantity() - selectedProduct.getQuantity();
                productRepository.updateQuantity(productMaster.getProduct_id(), updatedQuantity);
            }
        }
    }

    private void createTransactionDetailList(List<SelectedProduct> selectedProductList, Long id) {
        System.out.println("selectedProductList :: "+selectedProductList.size());
        for (SelectedProduct selectedproduct: selectedProductList) {
            TransactionDetail transactionDetail = new TransactionDetail();
            transactionDetail.setMaster_transaction_id(id);
            transactionDetail.setProduct_name(selectedproduct.getName());
            transactionDetail.setQuantity(selectedproduct.getQuantity());
            System.out.println("transactionDetail :: "+transactionDetail.toString());
            transactionDetailsDao.save(transactionDetail);
        }
    }
}
