package com.shop_account_maintance.Service;

import com.shop_account_maintance.Dao.SellProductRepository;
import com.shop_account_maintance.model.ProductMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SellProductService {
    @Autowired
    private SellProductRepository productRepository;

    public Iterable<ProductMaster> fetchAllProducts() {
        System.out.println("In servic class");
        return productRepository.findAll();
    }

    public void deleteProductFromSelectedList(Long id) {
        System.out.println("In deleteProductFromSelectedList :"+id);
        productRepository.delete(id);
    }
}
