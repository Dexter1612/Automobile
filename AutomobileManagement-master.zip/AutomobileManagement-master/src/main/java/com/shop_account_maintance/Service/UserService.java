package com.shop_account_maintance.Service;

import com.shop_account_maintance.Dao.UserRepository;
import com.shop_account_maintance.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userDao;
    
    public boolean isUserExist(User user) {
        System.out.println("INside isUserExist "+user.getUsername()+" ::0 "+user.getPassword());
    User dbUser = userDao.findByUserNamePassword(user.getUsername(), user.getPassword());
//        System.out.println("INside isUserExist "+dbUser.toString());

        return dbUser != null ? true: false;
    }

    public User registerUser(User user) {
        System.out.println("INside registerUser "+user.getUsername()+" :: "+user.getPassword());
        return userDao.save(user);
    }

    public Boolean isEmailExist(String email) {
        System.out.println("INside isEmailExist "+email);
        User user = userDao.isEmailExist(email);
        return user == null ? false : true;
    }
}
