package com.shop_account_maintance.Service;

import com.shop_account_maintance.utility.ExcelUtil;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;

@Service
public class PurchaseProductService {
    public void dumpFileIntoDB(MultipartFile file) throws IOException, SQLException {
        File simpleFile = new File("E:\\Projects Backup\\Automobile Billing\\purchase product.xlsx");
//        file.transferTo(simpleFile);
        ExcelUtil.readXLSFile(simpleFile);
    }

    public static void main(String[] args) throws IOException, SQLException {
//        PurchaseProductService obj = new PurchaseProductService();
        File simpleFile = new File("E:\\Projects Backup\\Automobile Billing\\purchase product.xlsx");

        ExcelUtil.readXLSFile(simpleFile);
    }
}
