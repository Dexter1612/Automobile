package com.shop_account_maintance.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.shop_account_maintance.Dao.PurchaseProductRepository;
import com.shop_account_maintance.model.ProductMaster;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

public class ExcelUtil {
	private static final Logger LOGGER= LoggerFactory.getLogger(ExcelUtil.class);
	@Autowired
	private static PurchaseProductRepository purchaseProductRepository;

	public static void readXLSFile(File file) throws IOException, SQLException {
		System.out.println("Reading XLS File....");
		FileInputStream readXlsfile = new FileInputStream(file);
		Workbook workbook = null;
		try {
			workbook = new HSSFWorkbook(readXlsfile);

			int productName = 0;
			int description = 0;
			int sellPrice = 0;
			int buyPrice = 0;
			int quantity = 0;

			Sheet sheet = workbook.getSheet("Sheet1");
			Iterator<Row> rowsDistributor = sheet.rowIterator();
			List<String> queries = new ArrayList<String>();
			while (rowsDistributor.hasNext()) {
				Row row = rowsDistributor.next();
				Iterator<Cell> cells = row.cellIterator();

				String productNameValue = null;
				String descriptionValue = null;
				String sellPriceValue = null;
				String buyPriceValue = null;
				String quantityValue = null;

				while (cells.hasNext()) {
					Cell cell = cells.next();
					if (cell.getRowIndex() == 0) {
						if (cell.getStringCellValue().equalsIgnoreCase(
								"Product Name")) {
							productName = cell.getColumnIndex();

						} else if (cell.getStringCellValue().equalsIgnoreCase(
								"Description")) {
							description = cell.getColumnIndex();

						} else if (cell.getStringCellValue().equalsIgnoreCase(
								"Buy Price")) {
							buyPrice = cell.getColumnIndex();

						} else if (cell.getStringCellValue().equalsIgnoreCase(
								"Sell Price")) {
							sellPrice = cell.getColumnIndex();

						} else if (cell.getStringCellValue().equalsIgnoreCase(
								"Quantity")) {
							quantity = cell.getColumnIndex();

						}
					}

					if (cell.getRowIndex() > 0) {
						// Read values

						if (cell.getColumnIndex() == productName) {
							productNameValue = cell.getStringCellValue();

						} else if (cell.getColumnIndex() == description) {
							descriptionValue = cell.getStringCellValue();

						} else if (cell.getColumnIndex() == buyPrice) {
							buyPriceValue = cell.getStringCellValue();

						} else if (cell.getColumnIndex() == sellPrice) {
							sellPriceValue = cell.getStringCellValue();

						} else if (cell.getColumnIndex() == quantity) {
							quantityValue = cell.getStringCellValue();

						}
					}
				}
				if (productNameValue != null && sellPriceValue != null
						&& quantityValue != null) {
					ProductMaster productMaster = purchaseProductRepository.isProductExist(productNameValue);
					if (productMaster != null && productMaster.getProduct_id() > 0) {
						int newQuantity = productMaster.getQuantity() + Integer.parseInt(quantityValue);
						purchaseProductRepository.updateProducts(productMaster.getProduct_id(), descriptionValue,
								Double.valueOf(buyPriceValue), Double.valueOf(sellPriceValue), newQuantity);
					} else {
						productMaster = new ProductMaster();
						productMaster.setProduct_name(productNameValue);
						productMaster.setDescription(descriptionValue);
						productMaster.setBuy_price(Double.valueOf(buyPriceValue));
						productMaster.setSell_price(Double.valueOf(sellPriceValue));
						productMaster.setQuantity(Integer.parseInt(quantityValue));
						productMaster.setInsert_date(new Timestamp(System.currentTimeMillis()));
						productMaster.setLast_modified(new Timestamp(System.currentTimeMillis()));
						purchaseProductRepository.save(productMaster);
					}

				}
			}
		}catch(Exception e){
				e.printStackTrace();
			}finally{
				if (readXlsfile != null) {
					readXlsfile.close();
				}
			}

	}
}
