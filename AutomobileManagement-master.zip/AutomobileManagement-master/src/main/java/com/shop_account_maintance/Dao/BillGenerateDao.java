package com.shop_account_maintance.Dao;

import com.shop_account_maintance.model.TransactionDetail;
import com.shop_account_maintance.model.TransactionMaster;
import org.springframework.data.jpa.repository.query.Procedure;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.sql.Timestamp;
import java.util.List;

@Repository
public interface BillGenerateDao extends CrudRepository<TransactionMaster, Long> {
    @Procedure(name = "submit_transaction")
    int insertTransactionIntoDB(@Param("p_amount") Double p_amount, @Param("p_bill_number") String p_bill_number,
                                @Param("p_customer_name") String p_customer_name,
                                @Param("p_discounted_amount") Double p_discounted_amount,
                                @Param("p_insert_time") Timestamp p_insert_time,
                                @Param("p_mobile_number") String p_mobile_number,
                                @Param("p_payment_type") String p_payment_type,@Param("p_sold_by") String p_sold_by,
                                @Param("p_status") String p_status, @Param("p_tax_amount") Double p_tax_amount);


}
