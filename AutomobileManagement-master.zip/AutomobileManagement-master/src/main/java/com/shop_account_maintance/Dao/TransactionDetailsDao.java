package com.shop_account_maintance.Dao;

import com.shop_account_maintance.model.TransactionDetail;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TransactionDetailsDao extends CrudRepository<TransactionDetail, Long> {
}
