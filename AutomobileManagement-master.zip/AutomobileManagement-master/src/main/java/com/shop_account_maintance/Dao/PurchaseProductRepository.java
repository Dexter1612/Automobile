package com.shop_account_maintance.Dao;

import com.shop_account_maintance.model.ProductMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface PurchaseProductRepository extends CrudRepository<ProductMaster, Long> {

    @Query(value = "SELECT p FROM PRODUCT_MASTER p WHERE p.product_name = :productNameValue")
    ProductMaster isProductExist(@Param("productNameValue") String productNameValue);

    /*@Query(value = "INSERT INTO product_master (product_name, description, buy_price, sell_price, quantity, " +
            "insert_date, last_modified ) " +
            " VALUES(:product_name, :description, :buy_price, :sell_price, :quantity, sysdate, sysdate )", nativeQuery=true)*/
    @Query(value = "INSERT INTO product_master (product_name, description, buy_price, sell_price, quantity, " +
            "insert_date, last_modified ) " +
            " VALUES(:product_name, :description, :buy_price, :sell_price, :quantity, sysdate, sysdate ) " +
            "ON DUPLICATE KEY UPDATE product_name = :product_name, description = :description, buy_price =:buy_price," +
            "sell_price = :sell_price, quantity =:quantity, insert_date = sysdate, last_modified = sysdate", nativeQuery=true)
    void updateOrInsertProducts(@Param("product_name") String product_name, @Param("description") String description,
                              @Param("buy_price") double buy_price, @Param("sell_price") double sell_price,
                              @Param("quantity") int quantity);

    @Query(value = "UPDATE PRODUCT_MASTER set QUANTITY = :quantityValue, buy_price = :buyPriceValue, description =:descriptionValue" +
            ",sell_price = :sellPriceValue, LAST_MODIFIED = sysdate() WHERE product_id = :product_id")
    void updateProducts(@Param("product_id") Long product_id, @Param("descriptionValue") String descriptionValue,
                        @Param("buyPriceValue") double buyPriceValue, @Param("sellPriceValue") double sellPriceValue,
                        @Param("quantityValue") int quantityValue);
}
