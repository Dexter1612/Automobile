package com.shop_account_maintance.Dao;

import com.shop_account_maintance.model.ProductMaster;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface ManageStockRepository extends CrudRepository<ProductMaster, Long> {

    @Query(value = "UPDATE PRODUCT_MASTER set QUANTITY = :quantity, PRODUCT_NAME = :productName, LAST_MODIFIED = sysdate() WHERE product_id = :id")
    int updateProductInDB(@Param("id") Long id, @Param("quantity") int quantity, @Param("productName") String productName);
}
