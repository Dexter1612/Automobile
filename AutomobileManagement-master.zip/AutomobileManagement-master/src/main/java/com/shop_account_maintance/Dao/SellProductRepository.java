package com.shop_account_maintance.Dao;

import com.shop_account_maintance.model.ProductMaster;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;

@Repository
public interface SellProductRepository extends CrudRepository<ProductMaster, Long> {

    @Transactional
    @Modifying
    @Query(value = "UPDATE PRODUCT_MASTER set QUANTITY = :quantity, LAST_MODIFIED = sysdate() WHERE product_id = :product_id")
    void updateQuantity(@Param("product_id") Long product_id, @Param("quantity") int quantity);
}
