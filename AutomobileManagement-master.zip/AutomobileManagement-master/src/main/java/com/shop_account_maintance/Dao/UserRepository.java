package com.shop_account_maintance.Dao;

import com.shop_account_maintance.model.User;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends CrudRepository<User, Long> {
    @Query(value = "SELECT u FROM USER u WHERE u.username = :username and u.password = :password")
    User findByUserNamePassword(@Param("username") String username, @Param("password") String password);

    @Query(value = "SELECT u FROM USER u WHERE u.email = :email")
    User isEmailExist(@Param("email") String email);
}
