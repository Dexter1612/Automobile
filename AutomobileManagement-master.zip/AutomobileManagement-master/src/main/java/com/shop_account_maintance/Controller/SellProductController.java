package com.shop_account_maintance.Controller;

import com.shop_account_maintance.Service.SellProductService;
import com.shop_account_maintance.model.ProductMaster;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class SellProductController {

    @Autowired
    private SellProductService sellProductService;

    @RequestMapping(value = "/sellProduct", method = RequestMethod.GET)
    public ModelAndView fetchAllProducts() {
        System.out.println("INside fetchAllProducts USer");
        Iterable<ProductMaster> listOfProduct = sellProductService.fetchAllProducts();
        List<ProductMaster> products = (List<ProductMaster>) listOfProduct;
        System.out.println("Size of fetchAllProducts :"+products.size());
        System.out.println("Size of fetchAllProducts :"+products);
        
        ModelAndView map = new ModelAndView("productList");
        map.addObject("products",products);
       return  map;
    }

    @RequestMapping(value = "/sellProductDelete")
    public String deleteProductFromSelectedList(@RequestParam("id") Long id){
//        sellProductService.deleteProductFromSelectedList(id);
        return "productList";
    }
    
    @RequestMapping(value = "/index1")
    public String index1(){
//        created to call index1.jsp
        return "index1";
    }
    @RequestMapping(value = "/insertDataInList")
    public String insertDataInList(){
//        created to call insertDataInList.jsp
        return "insertDataInList";
    }
}
