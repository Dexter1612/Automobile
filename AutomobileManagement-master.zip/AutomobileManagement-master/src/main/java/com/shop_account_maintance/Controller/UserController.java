package com.shop_account_maintance.Controller;

import com.shop_account_maintance.Service.UserService;
import com.shop_account_maintance.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.http.HttpSession;

@Controller
public class UserController {
    private static final Logger LOGGER=LoggerFactory.getLogger(UserController.class);
    @Autowired(required = true)
  //  @Qualifier("")
    private UserService userService;

    @GetMapping("/")
    public String index()
    {
        return "index";
    }

    @RequestMapping(value = "/loginUser",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public String loginUser(@RequestParam("username") String username, @RequestParam("password") String password, HttpSession session)
    {
        LOGGER.info("Inside Login USer"+username+" ::0 "+password);

        boolean isUserExist = false;
        if(username != null && password != null){
            User user = new User();
            user.setUsername(username);
            user.setPassword(password);
            System.out.println("get values"+user.getUsername()+" ::0 "+user.getPassword());
            session.setAttribute("username",username);
            isUserExist = userService.isUserExist(user);
        }
        return isUserExist ?  "home" : "index";
    }

    @RequestMapping(value = "/registerUser",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
    public String registerUser(@RequestParam("username") String username, @RequestParam("password") String password,
                               @RequestParam("name") String name, @RequestParam("email") String email, ModelAndView model)
    {
        User user = new User();
        user.setName(name);
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(password);
        user.setUserType("Normal");
        Boolean isEmailAlreadyRegistered = userService.isEmailExist(email);
        if(isEmailAlreadyRegistered){
            // code here for if emial aready registered
//            model.addObject("");
        }else {
            User registeredUser = userService.registerUser(user);
            System.out.println("registeredUser ::"+registeredUser.toString());
        }
        return "home";
    }
}
