package com.shop_account_maintance.Controller;

import com.shop_account_maintance.Service.ManageStockService;
import com.shop_account_maintance.model.ProductMaster;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

@Controller
public class ManageStockController {

    private static final Logger LOGGER= LoggerFactory.getLogger(ManageStockController.class);
    @Autowired
    private ManageStockService manageStockService;

    @RequestMapping(value = "/manageStock", method = RequestMethod.GET)
    public ModelAndView fetchAllProducts() {
        LOGGER.info("INside fetchAllProducts ManageStockController");
        Iterable<ProductMaster> listOfProduct = manageStockService.fetchAllProducts();
        List<ProductMaster> products = (List<ProductMaster>) listOfProduct;
        LOGGER.info("Size of fetchAllProducts :"+products.size());
        ModelAndView map = new ModelAndView("manageStock");
        map.addObject("productList",products);
        return  map;
    }

    @RequestMapping(value = "/manageStockDelete")
    public String deleteProductFromDB(@RequestParam("id") Long id){
        manageStockService.deleteProductFromDB(id);
        return "manageStock";
    }

    @RequestMapping(value = "/manageStockUpdate")
    public String updateProductInDB(@RequestParam("id") Long id, @RequestParam("quantity") int quantity,
                                    @RequestParam("productName") String productName){
        LOGGER.info("Inside ManageStockController : updateProductInDB "+id +" quantity:"+quantity+" productName:"+productName);
        manageStockService.updateProductInDB(id, quantity, productName);
        return "manageStock";
    }
}
