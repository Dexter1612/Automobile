package com.shop_account_maintance.Controller;

import com.shop_account_maintance.Service.BillGenerateService;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.SQLException;

@Controller
public class BillGenerateController {
    private static final Logger LOGGER= LoggerFactory.getLogger(BillGenerateController.class);
    @Autowired
    private BillGenerateService billGenerateService;

    @RequestMapping(value =  "/exportpage")
    public ModelAndView home() {
        ModelAndView model = new ModelAndView();

        model.setViewName("exportpdf");
        return model;
    }

    @RequestMapping(value = "/export")
    public void export(ModelAndView model, HttpServletResponse response) throws Exception {

        billGenerateService.insertTransactionIntoDB();
        LOGGER.info("####################################");
        JasperPrint jasperPrint = null;
        response.setContentType("application/x-download");
        response.setHeader("Content-Disposition", String.format("attachment; filename=\"users.pdf\""));
        OutputStream out = response.getOutputStream();
        jasperPrint = billGenerateService.exportPdfFile();
        JasperExportManager.exportReportToPdfStream(jasperPrint, out);
    }
}
