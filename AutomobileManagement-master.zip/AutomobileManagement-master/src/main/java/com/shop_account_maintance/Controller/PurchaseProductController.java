package com.shop_account_maintance.Controller;

import com.shop_account_maintance.Service.PurchaseProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;


@Controller
public class PurchaseProductController {

    @Autowired
    private PurchaseProductService purchaseProductService;

    @RequestMapping(value = "/uploadFile")
    public String uploadFile(@RequestParam("file") MultipartFile file, RedirectAttributes redirectAttributes) {
        try{
        if (file.isEmpty()) {
            redirectAttributes.addFlashAttribute("message", "Please select a file to upload");
            return "redirect:uploadStatus";
        }
            purchaseProductService.dumpFileIntoDB(file);
            redirectAttributes.addFlashAttribute("message",
                    "You have updated file successfully " + file.getOriginalFilename() + "'");
            return "purchaseProduct";
        }catch (Exception e){
            redirectAttributes.addFlashAttribute("message",
                    "Error while processing file.... " );
        }

        return "";

    }
}
